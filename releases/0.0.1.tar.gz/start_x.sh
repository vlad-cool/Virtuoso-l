#!/bin/bash
feh --bg-tile /usr/share/plymouth/themes/V24m_splash/throbber-0000.png
./app.py -r 90 -m monitor
